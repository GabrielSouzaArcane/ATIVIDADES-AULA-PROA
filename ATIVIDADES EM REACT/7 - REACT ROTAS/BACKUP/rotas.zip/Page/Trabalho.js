import '../App.css'
import TrabalhoConosco from './TrabalheConosco'
function Trabalho() {
    return (
        <div className='Trabalho'>
            <section className='fundoE'>
                <div className='fundoF'>
                    <h1>VENHA TRABALHAR CONOSCO!</h1>
                    <br />
                    
                    <div className='fundoF2'>
                        <p>
                        A Nossa Cultura é trabalhar sempre em
                        cooperação com a Nossa Gente. Acreditamos<br/>
                        que investir nos nossos colaboradores é trazer
                        ainda mais qualidade aos nosso negócios e aos<br/>
                        nossos produtos. Por isso, estamos sempre em busca<br/>
                        de novos talentos dispostos a dividir esse sonho grande
                        com a gente.
                        </p>
                    </div>
                    <br />
                    <br />
                    <br />
                    <div className='fundoF3'>
                        <br/>
                        <br/>
                        <br/>
                    <TrabalhoConosco />
                    </div>
                </div>
            </section>
        </div>
    )
}
export default Trabalho