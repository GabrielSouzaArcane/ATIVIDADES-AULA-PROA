import '../App.css'

function Atendimento() {
    return (
        <div className='Atendimento'>
            <section className='fundoG'>
                <div className='fundoH'>
                    <h1>Quer conhecer Asgard?</h1>
                    <h4>Venha fazer seu tour com a gente!</h4>
                    <br/>
                    <p>
                        Você pode conhcer cada detalhe bem pertinho, 
                        conhecer pessoalmente a cultura dos Vikings.
                        Sentir de perto a emoção dos contos sobre batalhas 
                        dos Berserkers, ver o próprio Miojnir e até mesmo 
                        beber de nossa preciosa cerveja! 
                    </p>
                    <h3>HORARIOS DISPONIVEIS</h3>
                    <p>
                        De segunda a sexta das 8:30 as 17 hr
                    </p>
                        <p>
                            <button>Agendar</button>
                            </p>
                            telefone pra contato 4002-8922
                </div>
            </section>
        </div>
    )
}

export default Atendimento